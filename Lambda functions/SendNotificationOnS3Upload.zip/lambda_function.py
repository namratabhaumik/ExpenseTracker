import json
import boto3

# Initialize SNS client
sns = boto3.client('sns')

def lambda_handler(event, context):
    try:
        # Validate the event format
        if 'Records' not in event or len(event['Records']) == 0:
            return {
                'statusCode': 400,
                'body': json.dumps("Error: Invalid event format. No records found.")
            }
        
        # Extract file details from the event (from S3)
        record = event['Records'][0]
        if 's3' not in record or 'object' not in record['s3']:
            return {
                'statusCode': 400,
                'body': json.dumps("Error: Missing S3 object data.")
            }

        file_name = record['s3']['object']['key']
        bucket_name = record['s3']['bucket']['name']

        # Construct the message for SNS
        message = f"A new file named {file_name} was uploaded to the bucket {bucket_name}."
        subject = "File Upload Notification"

        # Publish to SNS
        response = sns.publish(
            TopicArn='arn:aws:sns:us-east-1:897722688090:FileUploadNotification',  # Replace with your topic ARN
            Message=message,
            Subject=subject
        )

        # Check if SNS publish was successful
        if response['ResponseMetadata']['HTTPStatusCode'] != 200:
            return {
                'statusCode': 500,
                'body': json.dumps("Error: Failed to send SNS notification.")
            }

        return {
            'statusCode': 200,
            'body': json.dumps("SNS notification sent successfully.")
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error: {str(e)}")
        }
