import json
import boto3
from datetime import datetime

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('ExpensesTable')  # Ensure this table exists in DynamoDB

def lambda_handler(event, context):
    # Check if the event body is present
    if 'body' not in event or not event['body']:
        return {
            'statusCode': 400,
            'body': json.dumps('Missing request body')
        }
    
    try:
        # Parse the incoming request body
        body = json.loads(event['body'])

        # Extract individual fields
        user_id = body.get('UserId')
        expense_id = body.get('ExpenseId')
        amount = body.get('Amount')
        category = body.get('Category')

        # Validate required fields
        if not user_id:
            return {
                'statusCode': 400,
                'body': json.dumps('Missing required field: UserId')
            }
        if not expense_id:
            return {
                'statusCode': 400,
                'body': json.dumps('Missing required field: ExpenseId')
            }
        if not amount:
            return {
                'statusCode': 400,
                'body': json.dumps('Missing required field: Amount')
            }
        if not category:
            return {
                'statusCode': 400,
                'body': json.dumps('Missing required field: Category')
            }

        # Check if amount is a valid number
        if not isinstance(amount, (int, float)):
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid data type for Amount, must be a number')
            }

        # Check if category is a string
        if not isinstance(category, str):
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid data type for Category, must be a string')
            }

        # Create a new record with the current timestamp
        timestamp = str(datetime.now())

        # Attempt to insert into DynamoDB
        try:
            response = table.put_item(
                Item={
                    'UserId': user_id,
                    'ExpenseId': expense_id,
                    'Amount': amount,
                    'Category': category,
                    'Timestamp': timestamp
                }
            )

            # Check the response from DynamoDB
            if response['ResponseMetadata']['HTTPStatusCode'] == 200:
                return {
                    'statusCode': 200,
                    'body': json.dumps(f"Expense {expense_id} added successfully.")
                }
            else:
                return {
                    'statusCode': 500,
                    'body': json.dumps('Failed to add expense to DynamoDB')
                }

        except Exception as e:
            # Catch any DynamoDB-specific errors
            return {
                'statusCode': 500,
                'body': json.dumps(f"Error inserting data into DynamoDB: {str(e)}")
            }

    except json.JSONDecodeError:
        # Handle invalid JSON format
        return {
            'statusCode': 400,
            'body': json.dumps('Invalid JSON format')
        }
    except Exception as e:
        # Catch any other unforeseen errors
        return {
            'statusCode': 500,
            'body': json.dumps(f"An unexpected error occurred: {str(e)}")
        }
