import json
import boto3
from boto3.dynamodb.conditions import Key
from decimal import Decimal

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('ExpensesTable')  # Ensure this table exists in DynamoDB

# Custom JSON serializer to handle Decimal objects
class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            return float(o)  # Convert Decimal to float
        return super().default(o)

def lambda_handler(event, context):
    # Check if the event body is present
    if 'body' not in event or not event['body']:
        return {
            'statusCode': 400,
            'body': json.dumps('Missing request body')
        }

    try:
        # Parse the incoming request body
        body = json.loads(event['body'])

        # Extract individual fields
        user_id = body.get('UserId')
        expense_id = body.get('ExpenseId')

        # Validate required UserId field
        if not user_id:
            return {
                'statusCode': 400,
                'body': json.dumps('Missing required query parameter: UserId')
            }

        # If ExpenseId is provided, fetch a specific expense
        if expense_id:
            try:
                response = table.get_item(
                    Key={
                        'UserId': user_id,
                        'ExpenseId': expense_id
                    }
                )

                # Check if the item exists
                if 'Item' in response:
                    return {
                        'statusCode': 200,
                        'body': json.dumps(response['Item'], cls=DecimalEncoder)
                    }
                else:
                    return {
                        'statusCode': 404,
                        'body': json.dumps('Expense not found')
                    }

            except Exception as e:
                # Handle DynamoDB-specific errors
                return {
                    'statusCode': 500,
                    'body': json.dumps(f"Error retrieving data from DynamoDB: {str(e)}")
                }

        # If no ExpenseId, fetch all expenses for the UserId
        else:
            try:
                response = table.query(
                    KeyConditionExpression=boto3.dynamodb.conditions.Key('UserId').eq(user_id)
                )

                # Return the list of expenses
                return {
                    'statusCode': 200,
                    'body': json.dumps(response.get('Items', []), cls=DecimalEncoder)
                }

            except Exception as e:
                # Handle DynamoDB-specific errors
                return {
                    'statusCode': 500,
                    'body': json.dumps(f"Error querying data from DynamoDB: {str(e)}")
                }

    except Exception as e:
        # Handle unexpected errors
        return {
            'statusCode': 500,
            'body': json.dumps(f"An unexpected error occurred: {str(e)}")
        }
