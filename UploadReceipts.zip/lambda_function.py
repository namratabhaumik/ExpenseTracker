import json
import base64
import boto3
import jwt
import re
from decimal import Decimal

# Initialize AWS clients
s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
sns = boto3.client('sns')

# DynamoDB Table
table = dynamodb.Table('ExpensesTable')

bucket_name = 'my-finance-tracker-receipts'  # Your S3 bucket name

def decode_jwt_token(auth_header):
    """Decode the JWT token to extract user email."""
    try:
        token = auth_header.split(" ")[1]
        decoded_token = jwt.decode(token, options={"verify_signature": False})
        return decoded_token.get('email')
    except Exception as e:
        print(f"Error decoding token: {str(e)}")
        return None

def extract_receipt_data(receipt_text):
    """ Extract relevant data from the receipt text """
    # Extract date using regex
    date_pattern = r"Date:\s*(\d{4}-\d{2}-\d{2})"
    date_match = re.search(date_pattern, receipt_text)
    date = date_match.group(1) if date_match else "Unknown"

    # Extract total amount using regex
    total_pattern = r"Total:\s*\$([\d,.]+)"
    total_match = re.search(total_pattern, receipt_text)
    total = Decimal(total_match.group(1).replace(',', '')) if total_match else Decimal(0)

    # Extract Transaction ID using regex
    transaction_id_pattern = r"Transaction ID:\s*(\d+)"
    transaction_id_match = re.search(transaction_id_pattern, receipt_text)
    transaction_id = transaction_id_match.group(1) if transaction_id_match else "Unknown"

    return date, total, transaction_id

def lambda_handler(event, context):
    try:
        # Extract Authorization header
        auth_header = event.get('headers', {}).get('Authorization')
        if not auth_header:
            raise ValueError("Missing Authorization header.")

        # Decode JWT and extract user email
        user_email = decode_jwt_token(auth_header)
        if not user_email:
            raise ValueError("Invalid or missing email in token.")

        body = json.loads(event['body'])
        file_data = body['file']  # Base64 encoded file data
        file_name = body['fileName']  # Name of the file

        # Decode the base64 file data
        decoded_file_data = base64.b64decode(file_data)

        # Upload the file to S3
        s3.put_object(
            Bucket=bucket_name,
            Key=file_name,
            Body=decoded_file_data,
            Metadata={
                'uploaded-by': user_email
            }
        )

        # Process the uploaded file (assuming it's a receipt)
        receipt_text = decoded_file_data.decode('utf-8')
        receipt_date, total_amount, transaction_id = extract_receipt_data(receipt_text)

        # Store receipt data in DynamoDB
        receipt_data = {
            'UserId': user_email,  # Extracted from the JWT token
            'ExpenseId': transaction_id,
            'FileName': file_name,
            'Amount': total_amount,  # The total value from the receipt
            'Category': 'Food',  # Can be dynamically extracted or set
            'Timestamp': receipt_date  # Extracted date from the receipt
        }

        # Insert data into DynamoDB
        response = table.put_item(Item=receipt_data)

        if response['ResponseMetadata']['HTTPStatusCode'] != 200:
            raise ValueError("Failed to insert data into DynamoDB.")

        # Return success response
        return {
            'statusCode': 200,
            'body': json.dumps(f"File {file_name} uploaded and data processed successfully.")
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error: {str(e)}")
        }
